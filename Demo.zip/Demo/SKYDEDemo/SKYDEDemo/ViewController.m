//
//  ViewController.m
//  SKYDEDemo
//
//  Created by yeven on 2017/2/6.
//  Copyright © 2017年 Skyworth. All rights reserved.
//

#import "ViewController.h"
#import <SKYDESDK/SKYDESDK.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    __block BOOL connect  = YES;
    
    //搜索设备
    [[SKYDEManger sharedInstance] searchDevices:^(NSDictionary * _Nonnull device) {
        NSLog(@" device = %@", device);
        if (connect) {
            connect = NO;
            //连接搜索到的第一个设备
            [[SKYDEManger sharedInstance] connectDevice:device[@"ip"] clientName:@"TestDevices" callBack:^(BOOL success) {
                NSLog(@"connect %@",success?@"success":@"failed");
            }];
        }
    }];
    
    
    UIButton *testBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    testBtn.frame = CGRectMake(0, 20, self.view.frame.size.width, 80);
    testBtn.backgroundColor = [UIColor grayColor];
    [testBtn setTitle:@"TEST" forState:UIControlStateNormal];
    [testBtn addTarget:self action:@selector(testClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:testBtn];
}

//测试命令
- (void)testClick {
    NSArray *arr = @[SKY_KEY_HOME,SKY_KEY_RIGHT,SKY_KEY_RIGHT,SKY_KEY_LEFT,SKY_KEY_LEFT,SKY_KEY_BACK,SKY_KEY_VOLUME_UP,SKY_KEY_VOLUME_UP,SKY_KEY_VOLUME_UP,SKY_KEY_VOLUME_DOWN,SKY_KEY_VOLUME_DOWN];
    for (int i = 0; i < arr.count; i++) {
        NSLog(@"%@",arr[i]);
        [[SKYDEManger sharedInstance] controlTV:arr[i]];
        [NSThread sleepForTimeInterval:1.5];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
